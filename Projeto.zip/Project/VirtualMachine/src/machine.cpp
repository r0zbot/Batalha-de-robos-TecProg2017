#include <utility>

#include "../include/machine.h"

Machine::Machine(Instruction *prog) :
memo(100), data(512), exec(512), rbpStack(512) {
    this->prog = prog;
    this->ip = 0;
    this->rbp = 0;
    this->map_functions();
}

void Machine::add() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 + n2);
}

void Machine::allocate() {
    int size = this->fetch_arg();
    if (this->rbp + size < this->exec.get_size()){
        this->rbp += size;
        this->exec.set_rsp(this->rbp);
    }
    else{
        error("Memoria insuficiente na pilha de execucao");
    }
}

void Machine::call() {
    this->exec.push(this->ip);
    this->rbp = this->exec.get_rsp();
    this->rbpStack.push(this->rbp);
    this->jump();
}

void Machine::divide() {
    int den = this->data.top();
    this->data.pop();
    int num = this->data.top();
    this->data.pop();
    this->data.push(num / den);
}

void Machine::duplicate() {
    this->data.push(this->data.top());
}

void Machine::equals() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 == n2);
}

void Machine::execute() {
    bool run = true;
    while (run) {
        this->ip++;
        if (this->fetch_code() == Code::END) {
            run = false;
        }
        else {
            Function f = this->functions[this->fetch_code()];
            (this->*f)();
        }
    }
}

void Machine::free_memory() {
    this->rbp = this->rbpStack.top();
    this->exec.set_rsp(this->rbp);
}

void Machine::greater() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 < n2);
}

void Machine::greater_equal() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 <= n2);
}

void Machine::jump() {
    this->ip = this->fetch_arg();
}

void Machine::jump_if_false() {
    if (!this->data.top()) {
        this->jump();
    }
    this->data.pop();
}

void Machine::jump_if_true() {
    if (this->data.top()) {
        this->jump();
    }
    this->data.pop();
}

void Machine::lower() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 > n2);
}

void Machine::lower_equal() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 >= n2);
}

void Machine::multiply() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 * n2);
}

void Machine::not_equal() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n1 != n2);
}

void Machine::pop() {
    this->data.pop();
}

void Machine::print() {
    printf("%d\n", this->data.top());
    this->data.pop();
}

void Machine::push() {
    this->data.push(this->fetch_arg());
}

void Machine::rce(){
    int pos = this->rbpStack.top() - 1 + this->fetch_arg();
    if(pos<this->rbp){
        this->data.push(this->exec.get_position(pos));
    }
    else{
        error("Tentativa de acesso fora da zona alocada!");
    }
}

void Machine::return_from_procedure() {
    this->free_memory();
    this->ip = this->exec.top();
    this->rbpStack.pop();
    this->exec.pop();
}

void Machine::recall() {
    this->data.push(this->memo[this->fetch_arg()]);
}

void Machine::store() {
    this->memo[this->fetch_arg()] = this->data.top();
    this->data.pop();
}

void Machine::stl() {
    int pos = this->rbpStack.top() - 1 + this->fetch_arg();
    if(pos<this->rbp){
        this->exec.set_position(pos, this->data.top());
        this->data.pop();
    }
    else{
        error("Fora da memória local alocada");
    }
}

void Machine::subtract() {
    int n1 = this->data.top();
    this->data.pop();
    int n2 = this->data.top();
    this->data.pop();
    this->data.push(n2 - n1);
}

const int Machine::fetch_arg() const {
    return this->prog[this->ip - 1].get_arg();
}

const Code Machine::fetch_code() const {
    return this->prog[this->ip - 1].get_code();
}

void Machine::map_functions() {
    this->functions.insert(make_pair(Code::ADD,  &Machine::add));
    this->functions.insert(make_pair(Code::ALC,  &Machine::allocate));
    this->functions.insert(make_pair(Code::CALL, &Machine::call));
    this->functions.insert(make_pair(Code::DIV,  &Machine::divide));
    this->functions.insert(make_pair(Code::DUP,  &Machine::duplicate));
    this->functions.insert(make_pair(Code::EQ,   &Machine::equals));
    this->functions.insert(make_pair(Code::FRE,  &Machine::free_memory));
    this->functions.insert(make_pair(Code::GT,   &Machine::greater));
    this->functions.insert(make_pair(Code::GE,   &Machine::greater_equal));
    this->functions.insert(make_pair(Code::JMP,  &Machine::jump));
    this->functions.insert(make_pair(Code::JIF,  &Machine::jump_if_false));
    this->functions.insert(make_pair(Code::JIT,  &Machine::jump_if_true));
    this->functions.insert(make_pair(Code::LT,   &Machine::lower));
    this->functions.insert(make_pair(Code::LE,   &Machine::lower_equal));
    this->functions.insert(make_pair(Code::MUL,  &Machine::multiply));
    this->functions.insert(make_pair(Code::NE,   &Machine::not_equal));
    this->functions.insert(make_pair(Code::POP,  &Machine::pop));
    this->functions.insert(make_pair(Code::PRN,  &Machine::print));
    this->functions.insert(make_pair(Code::PUSH, &Machine::push));
    this->functions.insert(make_pair(Code::RCE,  &Machine::rce));
    this->functions.insert(make_pair(Code::RCL,  &Machine::recall));
    this->functions.insert(make_pair(Code::RET,  &Machine::return_from_procedure));
    this->functions.insert(make_pair(Code::STL,  &Machine::stl));
    this->functions.insert(make_pair(Code::STO,  &Machine::store));
    this->functions.insert(make_pair(Code::SUB,  &Machine::subtract));
}
